<!-- book donor-->
<?php
SESSION_START();
IF(!isset($_SESSION['in1'])||(isset($_SESSION['in1']) && $_SESSION['in1']!==TRUE))
{
echo "Acess Denied!!!";
exit();}
$phone=$_GET['name'];
$user=$_GET['user'];
include('connection.php');
mysql_query("UPDATE donate SET book = 1 WHERE phone='$phone'");
header("location:dlist.php?name=$user");
?>