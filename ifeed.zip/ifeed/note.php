﻿
<!-- show list of available areas-->
<html>


<!--[if lt IE 7]> <html class="lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->

<!--[if IE 7]> <html class="lt-ie9 lt-ie8" lang="en"> <![endif]-->
<!--[if IE 8]>
 <html class="lt-ie9" lang="en"> <![endif]-->

<!--[if gt IE 8]><!--> <html lang="en"> <!--<![endif]-->


<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

  <title>select area</title>

  <link rel="stylesheet" href="css2/style.css">
 
 <!--[if lt IE 9]><script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]-->

</head>


<body>
 
 <section class="container">
    
 <div class="dropdown">
 <form action="image.php"  method="POST" >
<select name="one" class="dropdown-select">
       
 <option value="">Select your area</option>
     
 
 <?php
 include('connection.php');
                $result = mysql_query("SELECT DISTINCT area FROM owner WHERE 1");
                if (mysql_num_rows($result) > 0) 
				{
				while($row =mysql_fetch_assoc($result))
                 {
 ?>
                <option value="<?php echo $row['area'];?>"><?php echo $row['area'];?></a></option>
     

 <?php }}else { echo "bab";} ?>
   </select>
   <input type="submit" >
   </form>
   
 </div>
</section>

 </body>

</html>
