<!-- show halls-->
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <title>Sign Up Form</title>
  <link rel="stylesheet" href="css/style.css">
  <!--[if lt IE 9]><script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
</head>
<?php
   $area=$_POST['two'];
   include('connection.php');
  $result1= mysql_query("SELECT name, contact, area, address, no FROM need WHERE area='$area'");
		if (mysql_num_rows($result1)>0) 
{
    // output data of each row
    ?>
<table bgcolor="#A9CCE3" align="center" class="sign-up-input"border="2" >
<tr>
<td> Name</td>
<td> contact</td>
<td> Area</td>
<td> Address</td>
<td> Number of People</td>
</tr>
<?php
	while($row1 =mysql_fetch_assoc($result1)) 
	{?>
       <tr>
	   <td><?php echo $row1['name'];?></td>
<td><?php echo $row1['contact'];?></td>
<td><?php echo $row1['area'];?></td>
<td><?php echo $row1['address'];?></td>
<td><?php echo $row1['no'];?></td>	   	   
</tr>

<?php
		
    }


	} 
?>
<a href="index.php" class="sign-up-input" >HOME</a>
<?php
		
 ?>