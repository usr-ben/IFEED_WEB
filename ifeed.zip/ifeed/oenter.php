<!-- enter email-->
<script type="text/javascript">
function validate(form)
{
//document.getElementById("new").innerHTML="asa";
var re=/^[a-z,A-Z,0-9,.,@,_]+$/i;
	if(!re.test(form.name.value)){
	document.getElementById("s").innerHTML="Email can contain only letters,numbers,@,.,_!!!";
	alert('Email can contain only letters,numbers,@,.,_');
	return false;
  }
  }
  </script>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <title>Sign Up Form</title>
  <link rel="stylesheet" href="css/style.css">
  <!--[if lt IE 9]><script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
</head>
<form class="sign-up" action="oforgot2.php" onsubmit="return validate(this);" method="POST" autocomplete="off">

		  <?php 
		  error_reporting(0);
		$remarks=$_GET['remarks'];
		if ($remarks==null and $remarks=="")
		{
		echo '';
		}
		else if($remarks=="'A'")
		{
		echo 'user does not exist!!!!';
		}
		else
		{
		echo 'Answer Wrong!!!!';
		}
		?>	
		<h1 class="sign-up-title">Enter your email</h1>
	      <h1 id="s" > </h1>
		  <input name="name" type="text" class="sign-up-input" placeholder="email" required autofocus> 
		   <input type="submit" value="Submit" class="sign-up-button">
  
</table>
</form>