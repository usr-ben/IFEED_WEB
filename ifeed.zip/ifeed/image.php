 
<!--display halls--> 


		<?php
   $area=$_POST['one'];
   include('connection.php');
   $result= mysql_query("SELECT email FROM owner WHERE area='$area'");
   if (mysql_num_rows($result) > 0) 
{
    // output data of each row
    while($row =mysql_fetch_assoc($result)) 
	{
        $temp=$row['email'];
		$result1= mysql_query("SELECT name,contact,hallname,descr,area,address FROM owner WHERE email='$temp'");
		if (mysql_num_rows($result1) > 0) 
{
    // output data of each row
	 while($row1 =mysql_fetch_assoc($result1)) 
	{
		$files = glob("$temp/*.*");
?>
   <?php

 
  for ($i=0; $i<count($files); $i++)

    {
	

$image = $files[$i];
$supported_file = array(
    'gif',
    'jpg',
    'jpeg',
    'png'
);

$ext = strtolower(pathinfo($image, PATHINFO_EXTENSION));
if (in_array($ext, $supported_file)) {


    echo '<img src="'.$image .'" alt="Random image" />';

                                                                              
                                           
	


}

}?>
<br>
		 <h1><?php echo $row1['hallname'];?> </h1> 
		 <?php echo $row1['address'].",".$row1['area'];?>
		
		 <br>
		<?php echo $row1['descr'];?>
<br>
<?php echo nl2br("Owner name:" . $row1['name'] . "  Contact no:" . $row1['contact'] . "\n\n");
		
		
		 
		
    }
} 
		
    }
} 
   
   
?>
