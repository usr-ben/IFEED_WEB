<!--list if available donors-->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,300italic,400">  <!-- Google web font "Open Sans" -->
        <link rel="stylesheet" href="css7/bootstrap.min.css">                                                <!-- Bootstrap style -->
        <link rel="stylesheet" href="css7/flexslider.css">                                                   <!-- Flexslider style -->       
        <link rel="stylesheet" href="css7/templatemo-style.css">     
<?php
SESSION_START();
IF(!isset($_SESSION['in1'])||(isset($_SESSION['in1']) && $_SESSION['in1']!==TRUE))
{
echo "Acess Denied!!!";
exit();}
   $temp=$_GET['name'];
   include('connection.php');
   $result1= mysql_query("SELECT name,phone,area,address,time FROM donate WHERE area='$temp' AND time>NOW() AND book=0");
		if (mysql_num_rows($result1) > 0) 
{
    // output data of each row
    ?>
	<p align="center">DONATORS LIST</p>
<table bgcolor="#A9CCE3" align="center" border="2" >
<tr>
<td> Name</td>
<td> phone</td>
<td> Area</td>
<td> Address</td>
<td> Time</td>
</tr>
<?php
	while($row1 =mysql_fetch_assoc($result1)) 
	{?>
       <tr>
	   <td><?php echo $row1['name'];?></td>
<td><?php echo $row1['phone'];?></td>
<td><?php echo $row1['area'];?></td>
<td><?php echo $row1['address'];?></td>	   
<td><?php echo $row1['time'];?></td>
	    <td> <a href="booked.php?name=<?php echo $row1['phone'];?>&user=<?php echo $area;?>">Booked</a></td>
</tr>
<?php
		
    }


	} 
		
    
?>
<a href="index.php">HOME</a>
<?php 
?>

   
   

