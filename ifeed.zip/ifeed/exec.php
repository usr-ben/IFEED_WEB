<!-- need  validation-->
<?php
session_start();

IF(!isset($_SESSION['nreg1'])||(isset($_SESSION['nreg1']) && $_SESSION['nreg1']!==TRUE))
{
echo "Acess Denied!!!";
exit();

}
include('connection.php');
$name=$_POST['name'];
$address=$_POST['address'];
$contact=$_POST['contact'];
$email=$_POST['mail'];
$password=$_POST['pass'];
$area=$_POST['area'];
$no=$_POST['no'];
$answer=$_POST['answer'];



// Remove all illegal characters from email
$email = filter_var($email, FILTER_SANITIZE_EMAIL);

// Validate e-mail
if (!filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
    echo("$email is a valid email address");
} else {
    echo("$email is not a valid email address");
     header("location:nreg.php");
	 exit();
	}
mysql_query("INSERT INTO need (name, contact, email, password, area, address, no, answer)VALUES('$name', '$contact', '$email', '$password', '$area', '$address', '$no', '$answer')") or die(header("location:nreg.php?remarks='a'"));


mysql_close($bd);
?>