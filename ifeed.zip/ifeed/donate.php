<script type="text/javascript">
function validate(form)
{
var	 re=/^[a-z,A-Z]+$/i;
	if(!re.test(form.name.value)){
	document.getElementById("s").innerHTML="Name can contain only letters!!!";
	alert('Name can contain only letters');
	return false;
  }
  var re=/^[0-9,+]+$/i;
	if(!re.test(form.contact.value)){
	document.getElementById("s").innerHTML="Contact can contain only numbers and +";
	alert('Contact can contain only numbers and +');
	return false;
  }var re=/^[a-z,A-Z,0-9]+$/i;
	if(!re.test(form.area.value)){
	document.getElementById("s").innerHTML="Area can contain only letters numbers";
	alert('Area can contain only letters numbers');
	return false;
  }var re=/^[a-z,A-Z,0-9,#,-,,]+$/i;
	if(!re.test(form.address.value)){
	document.getElementById("s").innerHTML="Address can contain only letters numbers and #,-,,";
	alert('Address can contain only letters numbers and #,-,,');
	return false;
  }var re=/^[-,0-9]+$/i;
	if(!re.test(form.time.value)){
	document.getElementById("s").innerHTML="date must be in yyyy-mm-dd format(ex: 2015-01=30)!!!";
	alert('date must be in yyyy-mm-dd format(ex: 2015-01=30)');
	return false;
	}
	}
	</script>
<!--[if lt IE 7]> <html class="lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if IE 7]> <html class="lt-ie9 lt-ie8" lang="en"> <![endif]-->
<!--[if IE 8]> <html class="lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html lang="en"> <!--<![endif]-->
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <title>Sign Up Form</title>
  <link rel="stylesheet" href="css/style.css">
  <!--[if lt IE 9]><script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
</head>
<style>
.city {
    float: left;
    margin: 5px;
    padding: 15px;
    width: 300px;
    height: 300px;
    border: 1px solid black;
} 
</style>
<body >
  <form class="sign-up" action="donate1.php" onsubmit="return validate(this);" method=post>
    <h1 class="sign-up-title">Donate in seconds</h1>
	 <h1 id="s" > </h1>
    <input name="name" type="text" class="sign-up-input" placeholder="your username?" autofocus>
    <input name="contact" type="text" class="sign-up-input" placeholder="contact number" autofocus>
	 <input name="area" type="text" class="sign-up-input" placeholder="your area" autofocus>
	  <input name="address" type="text" class="sign-up-input" placeholder="house no and cross no " autofocus>
	   <input name="time" type="text" class="sign-up-input" placeholder="date in format yyyy-mm-dd?" autofocus>
    <input type="submit" value="Donate!" class="sign-up-button">
  </form>
  <br>
  <h1 class="sign-up-button"><a href="look.php">Look for the nearest organiztions</a> </h1>
</body>
</html>
