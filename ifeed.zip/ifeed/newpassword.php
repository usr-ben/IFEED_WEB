<!--input new password-->

<?php
session_start();
IF(!isset($_SESSION['for'])||(isset($_SESSION['for']) && $_SESSION['for']!==TRUE))
{
echo "Acess Denied!!!";
exit();

}
$name=$_POST['name'];
$password=$_POST["password"];
echo $name;
require('connection.php');
$qry="UPDATE need SET password='$password' where email='$name'";
mysql_query($qry);
session_destroy();
header("location:nin.php");
?>