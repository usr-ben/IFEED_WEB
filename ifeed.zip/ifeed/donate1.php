<!--donate input-->
<?php
session_start();
include('connection.php');
$name=$_POST['name'];
$contact=$_POST['contact'];
$area=$_POST['area'];
$address=$_POST['address'];
$time=$_POST['time'];
mysql_query("INSERT INTO donate(name, phone, area, address, time, book)VALUES('$name', '$contact', '$area', '$address', '$time', '0')");
header("location:thanks.html");
mysql_close($con);
?>