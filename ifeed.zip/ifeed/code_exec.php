<!-- owner reg validation-->
<?php
session_start();
IF(!isset($_SESSION['reg2'])||(isset($_SESSION['reg2']) && $_SESSION['reg2']!==TRUE))
{
echo "Acess Denied!!!";
exit();
}
include('connection.php');
$name=$_POST['name'];
$address=$_POST['address'];
$contact=$_POST['contact'];
$email=$_POST['mail'];
$password=$_POST['pass'];
$area=$_POST['area'];
$hallname=$_POST['hallname'];
$descr=$_POST['descr'];
$answer=$_POST['answer'];
// Remove all illegal characters from email
$email = filter_var($email, FILTER_SANITIZE_EMAIL);

// Validate e-mail
if (!filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
    echo("$email is a valid email address");
} else {
    echo("$email is not a valid email address");
     header("location:register.php");
	 exit();
	}
mysql_query("INSERT INTO owner(name, contact, email, password, hallname, descr, area, address, answer)VALUES('$name', '$contact', '$email', '$password', '$hallname', '$descr', '$area', '$address', '$answer')")or die(header("location:register.php?remarks='a'"));
mkdir($email);
header("location: mysql.php?remarks=success");
mysql_close($con);
?>