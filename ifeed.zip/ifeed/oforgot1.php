<!--enter new password-->
<script type="text/javascript">
function validate(form)
{
//document.getElementById("new").innerHTML="asa";
var re=/^[a-z,A-Z,0-9,$,_]+$/i;
	if(!re.test(form.password.value)){
	document.getElementById("s").innerHTML="Password can contain only letters,numbers,$,_!!!";
	alert('Password can contain only letters,numbers,"$","_"');
	return false;
  }
  }
  </script>
  
<?php
session_start();
IF(!isset($_SESSION['reg3'])||(isset($_SESSION['reg3']) && $_SESSION['reg3']!==TRUE))
{
echo "Acess Denied!!!";
exit();

}
$answer=$_POST['answer'];
$name=$_REQUEST['name'];

require('connection.php');
$result=mysql_query("SELECT * FROM owner WHERE answer='$answer' AND email='$name'");

//Check whether the query was successful or not
	
if($result)	{
	if(mysql_num_rows($result) > 0) 
		{?>
			<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <title>Sign Up Form</title>
  <link rel="stylesheet" href="css/style.css">
  <!--[if lt IE 9]><script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
</head>
<form class="sign-up" name="reg" action="onewpassword.php" onsubmit="return validate(this);" method="post" autocomplete="off">

		  <?php 
		  error_reporting(0);
		  
		$_SESSION['ofor']=TRUE;
		$remarks=$_GET['remarks'];
		if ($remarks==null and $remarks=="")
		{
		echo '';
		}
		if ($remarks=='success')
		{
		echo 'Registration Success';
		}
		?>	
		<h1 class="sign-up-title">Enter new password</h1>
	      <h1 id="s" > </h1>
		  <input name="password" type="text" class="sign-up-input" placeholder="Password?" required autofocus>
		   <input type="hidden" name="name"  value="<?php echo $name; ?>" /> 
		   <input type="submit" value="SUBMIT" class="sign-up-button">
  
</table>
</form>
			
			<?php
		}
			else
			{
			header("location:oenter.php?remarks='b'");
		}
		}
		else{
		echo "hahaha";
}		
		
		
		
			?>	